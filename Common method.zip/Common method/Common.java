package com.vibesguide.comman;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Random;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpRequestBase;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.protocol.HTTP;
import org.apache.http.util.EntityUtils;
import org.json.JSONException;
import org.json.JSONObject;

import com.vibesguide.activity.R;

import android.app.Activity;
import android.app.ActivityManager;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.app.ActivityManager.RunningServiceInfo;
import android.content.Context;
import android.content.DialogInterface;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Rect;
import android.graphics.Bitmap.CompressFormat;
import android.graphics.drawable.Drawable;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Environment;
import android.os.Handler;
import android.os.Handler.Callback;
import android.os.Message;
import android.os.Vibrator;
import android.provider.Settings;
import android.telephony.TelephonyManager;
import android.telephony.gsm.SmsManager;
import android.text.Html;
import android.text.Spanned;
import android.util.Base64;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.Toast;
import cn.pedant.SweetAlert.SweetAlertDialog;

public class Common {

	static AlertDialog.Builder alert_box;
	static Location location;
	public static CharSequence INTERNET_NOTAVAIL = "Internet not available.";
	static Geocoder geocoder;
	static List<Address> addresses;
	public static ArrayList<String> CalendarDates = new ArrayList<String>();
	public static ArrayList<String> CalendarDatesForHomeScreen = new ArrayList<String>();
	public static String CalendarDate = "";
	public static String FormattedCalendarDate = "";
	public static boolean GooglePlusFlag = false;
	public static boolean ChooseLocationFlag = false;
	public static final String youTubeApiKey = "AIzaSyChtvnaCUE6X1XMrGgBE4rMN9aucFHqeqA";
	// public static final String URL = "http://112.196.61.52/vibesguide";
	// public static final String URI_REQUEST_LOGIN =
	// "http://112.196.61.52/vibesguide/api.aspx?method=login&type=json";
	// public static final String URI_REQUEST_SIGNUP =
	// "http://112.196.61.52/vibesguide/api.aspx?method=SignUp&type=json";
	// public static final String URI_REQUEST_FORGOTPASSWORD =
	// "http://112.196.61.52/vibesguide/api.aspx?method=ForgotPassword&type=json";
	// public static final String URI_REQUEST_EVENTLIST =
	// "http://112.196.61.52/vibesguide/api.aspx?method=getMultipleEventFromDateType&type=json";
	// //
	// public static final String URI_REQUEST_EVENTINFO =
	// "http://112.196.61.52/vibesguide/api.aspx?method=GetEventInfo1&type=json&style=false";
	// public static final String URI_REQUEST_SEARCHEVENT =
	// "http://112.196.61.52/vibesguide/api.aspx?method=GetMultipleSearchedEventsFromDateTypeKeyword1&type=json";
	// public static final String URI_REQUEST_TRANDINGINFO =
	// "http://112.196.61.52/vibesguide/api.aspx?method=GetTrendingEventsFromDate&type=json&style=false";
	// public static final String URI_REQUEST_CALENDAR =
	// "http://112.196.61.52/vibesguide/api.aspx?method=GetEventsDate&type=json";
	// public static final String URI_REQUEST_LIKEANDNOTIFICATION =
	// "http://112.196.61.52/vibesguide/api.aspx?method=AddEventNetworkStatusbyId&type=json";
	public static final String Create_Event_URL = "http://vibesguide.com/login?returnurl=publrdashboard";
	public static final String URL = "http://publishers.vibesguide.com/vibesguide";
	public static final String URI_REQUEST_LOGIN = "http://publishers.vibesguide.com/vibesguide/api.aspx?method=login&type=json";
	public static final String URI_REQUEST_SIGNUP = "http://publishers.vibesguide.com/vibesguide/api.aspx?method=SignUp&type=json";
	public static final String URI_REQUEST_FORGOTPASSWORD = "http://publishers.vibesguide.com/vibesguide/api.aspx?method=ForgotPassword&type=json";
	public static final String URI_REQUEST_EVENTLIST = "http://publishers.vibesguide.com/vibesguide/api.aspx?method=getMultipleEventFromDateType&type=json"; //
	public static final String URI_REQUEST_EVENTINFO = "http://publishers.vibesguide.com/vibesguide/api.aspx?method=GetEventInfo2&type=json&style=false";
	public static final String URI_REQUEST_SEARCHEVENT = "http://publishers.vibesguide.com/vibesguide/api.aspx?method=GetMultipleSearchedEventsFromDateTypeKeyword1&type=json";
	public static final String URI_REQUEST_TRANDINGINFO = "http://publishers.vibesguide.com/vibesguide/api.aspx?method=GetTrendingEventsFromDate&type=json&style=false";
	public static final String URI_REQUEST_CALENDAR = "http://publishers.vibesguide.com/vibesguide/api.aspx?method=GetEventsDate&type=json";
	public static final String URI_REQUEST_LIKEANDNOTIFICATION = "http://publishers.vibesguide.com/vibesguide/api.aspx?method=AddEventNetworkStatusbyId&type=json";
	public static final String URI_REQUEST_WetherInfo = "http://publishers.vibesguide.com/vibesguide/weather.aspx?method=getweatherinfo&type=xml";
	public static final String URI_REQUEST_USER_PROFILE = "http://publishers.vibesguide.com/vibesguide/api.aspx?method=GetEventManagerInfo&type=json";

	// to show toast on screen
	public static void showToast(String msg, Context context) {
		try {
			Toast.makeText(context, msg, Toast.LENGTH_LONG).show();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static void sendSMS(String paramString1, String paramString2) {
		try {
			SmsManager.getDefault().sendTextMessage(paramString1, null,
					paramString2, null, null);
			return;
		} catch (Exception localException) {

			localException.printStackTrace();
		}
	}

	public static void vibrate(Context context) {
		Vibrator v = (Vibrator) context
				.getSystemService(Context.VIBRATOR_SERVICE);
		// Vibrate for 500 milliseconds
		v.vibrate(50);
	}

	public static String getCurrentTimeStampOfDevice() {
		String timeStamp = "";
		int mDayF, mDayT, mDayD, mDayU, mMonthF, mMonthD, mMonthT, mMonthU, mYearF, mYearD, mYearT, mYearU, mYear, mMonth, mDay, mH, mM, mS;

		final Calendar c = Calendar.getInstance();
		mYear = mYearF = mYearT = mYearD = mYearU = c.get(Calendar.YEAR);
		mMonth = mMonthF = mMonthT = mMonthD = mMonthU = c.get(Calendar.MONTH);
		mDay = mDayF = mDayT = mDayD = mDayU = c.get(Calendar.DAY_OF_MONTH);
		mH = c.get(Calendar.HOUR_OF_DAY);
		mM = c.get(Calendar.MINUTE);
		mS = c.get(Calendar.SECOND);
		String Current_Time_Stamp = "" + pad(mDay) + "-" + pad((mMonth + 1))
				+ "-" + pad(mYear) + "  " + pad(mH) + ":" + pad(mM) + ":"
				+ pad(mS);
		return timeStamp = Current_Time_Stamp;
	}

	public static String getCurrentTimeStampOfDeviceForOrderAndCustomerReload() {
		String timeStamp = "";
		int mDayF, mDayT, mDayD, mDayU, mMonthF, mMonthD, mMonthT, mMonthU, mYearF, mYearD, mYearT, mYearU, mYear, mMonth, mDay, mH, mM, mS;

		final Calendar c = Calendar.getInstance();
		mYear = mYearF = mYearT = mYearD = mYearU = c.get(Calendar.YEAR);
		mMonth = mMonthF = mMonthT = mMonthD = mMonthU = c.get(Calendar.MONTH);
		mDay = mDayF = mDayT = mDayD = mDayU = c.get(Calendar.DAY_OF_MONTH);
		mH = c.get(Calendar.HOUR_OF_DAY);
		mM = c.get(Calendar.MINUTE);
		mS = c.get(Calendar.SECOND);
		String Current_Time_Stamp = "" + pad(mYear) + "-" + pad((mMonth + 1))
				+ "-" + pad(mDay) + "  " + pad(mH) + ":" + pad(mM) + ":"
				+ pad(mS);
		return timeStamp = Current_Time_Stamp;
	}

	public static String getCurrentTimeStampInMilliSeconds() {
		String timeStamp = "";
		int mDayF, mDayT, mDayD, mDayU, mMonthF, mMonthD, mMonthT, mMonthU, mYearF, mYearD, mYearT, mYearU, mYear, mMonth, mDay, mH, mM, mS;

		final Calendar c = Calendar.getInstance();
		mYear = mYearF = mYearT = mYearD = mYearU = c.get(Calendar.YEAR);
		mMonth = mMonthF = mMonthT = mMonthD = mMonthU = c.get(Calendar.MONTH);
		mDay = mDayF = mDayT = mDayD = mDayU = c.get(Calendar.DAY_OF_MONTH);
		mH = c.get(Calendar.HOUR_OF_DAY);
		mM = c.get(Calendar.MINUTE);
		mS = c.get(Calendar.SECOND);
		String Current_Time_Stamp = String.valueOf(c.getTimeInMillis());
		return timeStamp = Current_Time_Stamp;
	}

	public static String getCurrentTimeOfDevice() {
		String timeStamp = "";
		int mDayF, mDayT, mDayD, mDayU, mMonthF, mMonthD, mMonthT, mMonthU, mYearF, mYearD, mYearT, mYearU, mYear, mMonth, mDay, mH, mM, mS;

		final Calendar c = Calendar.getInstance();
		mYear = mYearF = mYearT = mYearD = mYearU = c.get(Calendar.YEAR);
		mMonth = mMonthF = mMonthT = mMonthD = mMonthU = c.get(Calendar.MONTH);
		mDay = mDayF = mDayT = mDayD = mDayU = c.get(Calendar.DAY_OF_MONTH);
		mH = c.get(Calendar.HOUR_OF_DAY);
		mM = c.get(Calendar.MINUTE);
		mS = c.get(Calendar.SECOND);
		String Current_Time_Stamp = "" + pad(mH) + ":" + pad(mM) + ":"
				+ pad(mS);
		return timeStamp = Current_Time_Stamp;
	}

	public static String getCurrentDateOfDevice() {
		String timeStamp = "";
		int mDayF, mDayT, mDayD, mDayU, mMonthF, mMonthD, mMonthT, mMonthU, mYearF, mYearD, mYearT, mYearU, mYear, mMonth, mDay, mH, mM, mS;

		final Calendar c = Calendar.getInstance();
		mYear = mYearF = mYearT = mYearD = mYearU = c.get(Calendar.YEAR);
		mMonth = mMonthF = mMonthT = mMonthD = mMonthU = c.get(Calendar.MONTH);
		mDay = mDayF = mDayT = mDayD = mDayU = c.get(Calendar.DAY_OF_MONTH);
		mH = c.get(Calendar.HOUR_OF_DAY);
		mM = c.get(Calendar.MINUTE);
		mS = c.get(Calendar.SECOND);
		String Current_Time_Stamp = "" + pad(mMonth + 1) + "/" + pad((mDay))
				+ "/" + pad(mYear);
		return timeStamp = Current_Time_Stamp;
	}

	public static String getMonth(String month) {
		if (month.equalsIgnoreCase("01")) {
			month = "Jan";
		} else if (month.equalsIgnoreCase("02")) {
			month = "Feb";
		} else if (month.equalsIgnoreCase("03")) {
			month = "March";
		} else if (month.equalsIgnoreCase("04")) {
			month = "April";
		} else if (month.equalsIgnoreCase("05")) {
			month = "May";
		} else if (month.equalsIgnoreCase("06")) {
			month = "June";
		} else if (month.equalsIgnoreCase("07")) {
			month = "July";
		} else if (month.equalsIgnoreCase("08")) {
			month = "Aug";
		} else if (month.equalsIgnoreCase("09")) {
			month = "Sep";
		} else if (month.equalsIgnoreCase("10")) {
			month = "Oct";
		} else if (month.equalsIgnoreCase("11")) {
			month = "Nov";
		} else if (month.equalsIgnoreCase("12")) {
			month = "Dec";
		}
		return month;
	}

	public static String getMonth2(String month) {
		if (month.equalsIgnoreCase("1")) {
			month = "Jan";
		} else if (month.equalsIgnoreCase("2")) {
			month = "Feb";
		} else if (month.equalsIgnoreCase("3")) {
			month = "March";
		} else if (month.equalsIgnoreCase("4")) {
			month = "April";
		} else if (month.equalsIgnoreCase("5")) {
			month = "May";
		} else if (month.equalsIgnoreCase("6")) {
			month = "June";
		} else if (month.equalsIgnoreCase("7")) {
			month = "July";
		} else if (month.equalsIgnoreCase("8")) {
			month = "Aug";
		} else if (month.equalsIgnoreCase("9")) {
			month = "Sep";
		} else if (month.equalsIgnoreCase("10")) {
			month = "Oct";
		} else if (month.equalsIgnoreCase("11")) {
			month = "Nov";
		} else if (month.equalsIgnoreCase("12")) {
			month = "Dec";
		}
		return month;
	}

	public static String pad(int c) {
		if (c >= 10)
			return String.valueOf(c);
		else
			return "0" + String.valueOf(c);
	}

	static public String urlEncodeForMsg(String sUrl) {
		StringBuffer urlOK = new StringBuffer();
		for (int i = 0; i < sUrl.length(); i++) {
			char ch = sUrl.charAt(i);
			switch (ch) {
			case '<':
				urlOK.append("%3C");
				break;
			case '>':
				urlOK.append("%3E");
				break;
			case ' ':
				urlOK.append("%20");
				break;
			case '-':
				urlOK.append("%2D");
				break;
			case '@':
				urlOK.append("%40");
				break;
			case '|':
				urlOK.append("%7C");
				break;
			default:
				urlOK.append(ch);
				break;
			}
		}
		return urlOK.toString().trim();
	}

	public static final int getScreenDensity(Context contex) {

		int density = contex.getResources().getDisplayMetrics().densityDpi;
		int den = 0;
		switch (density) {
		case DisplayMetrics.DENSITY_HIGH:
			den = 12;
			break;
		case DisplayMetrics.DENSITY_MEDIUM:
			den = 14;
			break;
		case DisplayMetrics.DENSITY_LOW:
			den = 10;
			break;
		case DisplayMetrics.DENSITY_XHIGH:
			den = 26;
			break;
		case DisplayMetrics.DENSITY_XXHIGH:
			den = 25;
			break;
		case DisplayMetrics.DENSITY_TV:
			den = 35;
			break;

		default:
			den = 35;
			break;
		}
		return den;
	}

	public static final int getpopHeight(Context contex) {

		int density = contex.getResources().getDisplayMetrics().densityDpi;
		int den = 0;
		switch (density) {
		case DisplayMetrics.DENSITY_HIGH:
			den = 130;
			break;
		case DisplayMetrics.DENSITY_MEDIUM:
			den = 120;
			break;
		case DisplayMetrics.DENSITY_LOW:
			den = 100;
			break;
		case DisplayMetrics.DENSITY_XHIGH:
			den = 165;
			break;
		case DisplayMetrics.DENSITY_XXHIGH:
			den = 240;
			break;
		case DisplayMetrics.DENSITY_TV:
			den = 35;
			break;

		default:
			den = 340;
			break;
		}
		return den;
	}

	public static final int getpopWeidht(Context contex) {

		int density = contex.getResources().getDisplayMetrics().densityDpi;
		int den = 0;
		switch (density) {
		case DisplayMetrics.DENSITY_HIGH:
			den = 250;
			break;
		case DisplayMetrics.DENSITY_MEDIUM:
			den = 230;
			break;
		case DisplayMetrics.DENSITY_LOW:
			den = 200;
			break;
		case DisplayMetrics.DENSITY_XHIGH:
			den = 250;
			break;
		case DisplayMetrics.DENSITY_XXHIGH:
			den = 500;
			break;
		case DisplayMetrics.DENSITY_TV:
			den = 35;
			break;

		default:
			den = 500;
			break;
		}
		return den;
	}

	public static final float getScreenDensityfloat(Context contex) {
		int density = contex.getResources().getDisplayMetrics().densityDpi;
		float den = 0f;
		switch (density) {
		case DisplayMetrics.DENSITY_HIGH:
			den = 12f;
			break;
		case DisplayMetrics.DENSITY_MEDIUM:
			den = 14f;
			break;
		case DisplayMetrics.DENSITY_LOW:
			den = 10f;
			break;
		case DisplayMetrics.DENSITY_XHIGH:
			den = 26f;
			break;
		case DisplayMetrics.DENSITY_XXHIGH:
			den = 25f;
			break;
		case DisplayMetrics.DENSITY_TV:
			den = 35f;
			break;

		default:
			den = 35f;
			break;
		}
		return den;
	}

	// Check string has value or not...
	public static boolean HasValue(Object input) {
		if (input == null || input.toString().length() == 0
				|| "".equals(input.toString().trim())) {
			return false;
		}
		return true;
	}

	public static String getMeNthParamInString(String p_text,
			String p_seperator, int nThParam) { // / "TOTRPIDS=101=104" returns
												// "101" If nThParam ==
												// 2.
		String retStrThirdParam = new String("**");
		int index = -1;
		int prevIdx = 0;
		int loopNM = 1;
		boolean loopBool = true;
		while (loopBool) {
			try {
				index = p_text.indexOf(p_seperator, prevIdx);
				if (loopNM >= nThParam) {
					if (index >= 0) {
						retStrThirdParam = p_text.substring(prevIdx, index);
					} else // /-1
					{
						retStrThirdParam = p_text.substring(prevIdx);
					}
					loopBool = false;
					break;
				} else {
					if (index < 0) // /-1
					{
						loopBool = false;
						retStrThirdParam = "**";
						break;
					}
				}
				loopNM++;
				prevIdx = index + 1;
			} catch (Exception ex) {
				loopBool = false;
				retStrThirdParam = "**";
				break;
			}
		} // /while
		if (retStrThirdParam.trim().length() <= 0) {
			retStrThirdParam = "**";
		}
		return retStrThirdParam;
	}

	public static boolean isNetworkConnectionAvailable(Context context) {
		ConnectivityManager cm = (ConnectivityManager) context
				.getSystemService(Context.CONNECTIVITY_SERVICE);
		android.net.NetworkInfo ni = cm.getActiveNetworkInfo();
		if (ni != null && ni.isAvailable() && ni.isConnected()) {
			return true;
		} else {
			return false;
		}

	}

	public static String down(String string) {

		try {
			URL url = new URL(string);
			HttpURLConnection c = (HttpURLConnection) url.openConnection();
			c.setRequestMethod("GET");
			c.setDoOutput(true);
			c.connect();

			String PATH = Environment.getExternalStorageDirectory().toString()
					+ "/MagTrack";

			File file = new File(PATH);
			file.mkdirs();
			File outputFile = new File(file, "MagTrack"
					+ Calendar.getInstance().getTimeInMillis() + ".apk");
			FileOutputStream fos = new FileOutputStream(outputFile);
			InputStream is = c.getInputStream();

			byte[] buffer = new byte[4096];
			int len1 = 0;

			while ((len1 = is.read(buffer)) != -1) {
				fos.write(buffer, 0, len1);
			}

			fos.close();
			is.close();
			return outputFile.getAbsolutePath();

		} catch (IOException e) {
			e.printStackTrace();
			return null;
		}

	}

	@SuppressWarnings("deprecation")
	public static boolean isAirplaneModeOn(Context context) {
		return Settings.System.getInt(context.getContentResolver(),
				Settings.System.AIRPLANE_MODE_ON, 0) != 0;
	}

	// /Download pdf from server
	public static void DownloadFile(String fileURL, File directory) {
		try {

			FileOutputStream f = new FileOutputStream(directory);
			URL u = new URL(fileURL);
			HttpURLConnection c = (HttpURLConnection) u.openConnection();
			c.setRequestMethod("GET");
			c.setDoOutput(true);
			c.connect();

			InputStream in = c.getInputStream();

			byte[] buffer = new byte[1024];
			int len1 = 0;
			while ((len1 = in.read(buffer)) > 0) {
				f.write(buffer, 0, len1);
			}
			f.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void DownloadFilePDF(Context context, final String fileURL,
			final File directory) {// Download PDF File from url

		try {
			final ProgressDialog pd = ProgressDialog.show(context,
					"Please Wait", "Data sync...");
			final Handler handler = new Handler(new Callback() {

				@Override
				public boolean handleMessage(Message msg) {
					// TODO Auto-generated method stub

					pd.dismiss();
					return true;
				}
			});
			new Thread(new Runnable() {
				@Override
				public void run() {

					try {

						FileOutputStream f = new FileOutputStream(directory);
						URL u = new URL(fileURL);
						HttpURLConnection c = (HttpURLConnection) u
								.openConnection();
						c.setRequestMethod("GET");
						c.setDoOutput(true);
						c.connect();

						InputStream in = c.getInputStream();

						byte[] buffer = new byte[1024];
						int len1 = 0;
						while ((len1 = in.read(buffer)) > 0) {
							f.write(buffer, 0, len1);
						}
						f.close();
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					handler.sendEmptyMessage(0);
				}
			}).start();

		} catch (Exception exc) {
			exc.printStackTrace();
		} finally {

		}
	}

	// Check SIM available or not
	public static boolean isSimAvailable(Context context) {

		TelephonyManager tm = (TelephonyManager) context
				.getSystemService(Context.TELEPHONY_SERVICE);
		if (tm.getSimState() != TelephonyManager.SIM_STATE_ABSENT) {
			return true;
		} else {
			return false;
		}
	}

	// dialog popup when Internet is not available
	public static void noInternetConnection(Context context) {
		new SweetAlertDialog(context, SweetAlertDialog.ERROR_TYPE)
				.setTitleText("Oops...")
				.setContentText(INTERNET_NOTAVAIL.toString()).show();
	}

	public static void ApiErrorMSG(String MSG, Context context) {
		new SweetAlertDialog(context, SweetAlertDialog.ERROR_TYPE)
				.setTitleText("Information...").setContentText(MSG).show();
	}

	public static void ForgotPasswordSuccess(String MSG, Context context) {
		new SweetAlertDialog(context, SweetAlertDialog.SUCCESS_TYPE)
				.setTitleText("Information...").setContentText(MSG).show();
	}

	// dialog popup to user when server is not responding ..
	public static void ServernotResponding(Context context) {
		new SweetAlertDialog(context, SweetAlertDialog.ERROR_TYPE)
				.setTitleText("Oops...")
				.setContentText("Server time out, please try again.").show();
	}

	public static void LogInDialog(String MSG, Context context) {
		new SweetAlertDialog(context, SweetAlertDialog.NORMAL_TYPE)
				.setTitleText("Information...").setContentText(MSG).show();
	}

	public static boolean isEmailValid(String email) {
		boolean isValid = false;

		String expression = "^[\\w\\.-]+@([\\w\\-]+\\.)+[A-Z]{2,4}$";
		CharSequence inputStr = email;

		Pattern pattern = Pattern.compile(expression, Pattern.CASE_INSENSITIVE);
		Matcher matcher = pattern.matcher(inputStr);
		if (matcher.matches()) {
			isValid = true;
		}
		return isValid;
	}

	public static void ConfirmDialog(Context context, String MSG) {
		alert_box = new AlertDialog.Builder(context);
		alert_box.setTitle("Confirmation !");
		alert_box.setMessage(MSG);
		alert_box.setPositiveButton("OK",
				new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface dialog, int which) {

					}
				});

		alert_box.show();
	}

	public static String convertthumb(Bitmap mBitmap) {

		ByteArrayOutputStream out = new ByteArrayOutputStream();
		if (mBitmap != null) {
			mBitmap.compress(Bitmap.CompressFormat.JPEG, 100, out);
		}
		byte[] imageThumbnail = out.toByteArray();

		String string = Base64.encodeToString(imageThumbnail, Base64.DEFAULT);
		return string;
	}

	public static URL ConvertToUrl(String urlStr) {
		try {
			URL url = new URL(urlStr);
			URI uri = new URI(url.getProtocol(), url.getUserInfo(),
					url.getHost(), url.getPort(), url.getPath(),
					url.getQuery(), url.getRef());
			url = uri.toURL();
			return url;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	/**
	 * @param encodedString
	 * @return bitmap (from given string)
	 */
	public static Bitmap StringToBitMap(String encodedString) {
		try {
			byte[] encodeByte = Base64.decode(encodedString, Base64.DEFAULT);
			Bitmap bitmap = BitmapFactory.decodeByteArray(encodeByte, 0,
					encodeByte.length);
			return bitmap;
		} catch (Exception e) {
			e.getMessage();
			return null;
		}
	}

	public static Boolean validateEmail(String inputMail) {
		CharSequence pattern = "@.";
		for (int i = 0; i < pattern.length(); i++) {
			if (inputMail.indexOf(pattern.charAt(i)) < 1)
				return false;
		}
		return true;
	}

	public static Rect locateView(View v) {
		int[] location = new int[2];
		if (v == null)
			return null;
		try {
			v.getLocationOnScreen(location);
		} catch (NullPointerException npe) {
			// Happens when the view doesn't exist on screen anymore.
			return null;
		}
		Rect locationTemp = new Rect();
		locationTemp.left = location[0];
		locationTemp.top = location[1];
		locationTemp.right = locationTemp.left + v.getWidth();
		locationTemp.bottom = locationTemp.top + v.getHeight();
		return locationTemp;
	}

	public static int convertDpToPixel(float dp, Context context) {
		Resources resources = context.getResources();
		DisplayMetrics metrics = resources.getDisplayMetrics();
		float px = dp * (metrics.densityDpi / 160f);
		return (int) px;
	}

	public static int convertPixelsToDp(float px, Context context) {
		Resources resources = context.getResources();
		DisplayMetrics metrics = resources.getDisplayMetrics();
		int dp = (int) (px / (metrics.densityDpi / 160f));
		return dp;
	}

	public static String convertStringToTime(String sTime) {
		String time = "";
		sTime = sTime.toLowerCase();
		time = sTime;
		if (sTime.contains("pm")) {
			sTime = sTime.substring(0, sTime.indexOf("p"));
			sTime = sTime.substring(sTime.indexOf(":"));
			if (Integer.parseInt(time.substring(0, time.indexOf(":"))) < 12)
				time = (Integer.parseInt(time.substring(0, time.indexOf(":"))) + 12)
						+ sTime;
			else
				time = (Integer.parseInt(time.substring(0, time.indexOf(":"))))
						+ sTime;

		} else
			time = time.substring(0, time.indexOf("a"));
		return time;
	}

	public static Bitmap decodeFile(File f, int REQUIRED_WIDTH,
			int REQUIRED_HEIGHT) {
		try {
			// Decode image size
			BitmapFactory.Options o = new BitmapFactory.Options();
			o.inJustDecodeBounds = true;
			BitmapFactory.decodeStream(new FileInputStream(f), null, o);

			// Find the correct scale value. It should be the power of 2.
			int scale = 1;
			while (o.outWidth / scale >= REQUIRED_WIDTH
					&& o.outHeight / scale >= REQUIRED_HEIGHT)
				scale *= 2;

			// Decode with inSampleSize
			if (scale != 1) {
				BitmapFactory.Options o2 = new BitmapFactory.Options();
				o2.inSampleSize = scale;
				return BitmapFactory.decodeStream(new FileInputStream(f), null,
						o2);
			} else {
				return BitmapFactory.decodeFile(f.getAbsolutePath());

			}
		} catch (FileNotFoundException e) {

		} catch (Exception ex) {
			// BitmapFactory.Options opt = new BitmapFactory.Options();
			// opt.inSampleSize = 2;
			// try {
			// return BitmapFactory.decodeStream(new FileInputStream(f), null,
			// opt);
			// } catch (FileNotFoundException e1) {
			// // TODO Auto-generated catch block
			// e1.printStackTrace();
			// }
		}
		return null;
	}

	// Format phone number...
	public static String formatPhoneNumber(String input) {
		if (input.length() <= 4) {
			return input;
		} else if (input.length() > 4 && input.length() <= 7) {
			return input.substring(0, input.length() - 4) + "-"
					+ input.substring(input.length() - 4, input.length());
		} else if (input.length() > 7) {
			return input.substring(0, input.length() - 7) + "-"
					+ input.substring(input.length() - 7, input.length() - 4)
					+ "-" + input.substring(input.length() - 4, input.length());
		}
		return "";
	}

	public static boolean HasDoubleValue(Object input) {
		if (input == null || input.toString().length() == 0
				|| "".equals(input.toString().trim())
				|| ".".equals(input.toString().trim())) {
			return false;
		}
		return true;
	}

	public static String GenerateRandomString(int size) {
		StringBuilder builder = new StringBuilder();
		Random random = new Random();
		char ch;
		for (int i = 0; i < size; i++) {
			ch = (char) (random.nextInt(26) + 65);
			builder.append(ch);
		}
		return builder.toString();
	}

	public static void DoCatchOperation(Throwable ex) {
		Log.e("bhavesh", "Exception: " + ex.getMessage());
		// CollectionList.GenerateException(CommonFunctions.GetStackTrace(ex));
		// e.printStackTrace();
	}

	// Get image from web url...
	public static Drawable ImageOperations(String url) {
		try {
			Object obj = fetch(url);
			if (obj == null)
				return null;
			InputStream is = (InputStream) fetch(url);
			Drawable d = Drawable.createFromStream(is, "src");
			return d;
		} catch (Exception e) {
			Common.DoCatchOperation(e);
			return null;
		}
	}

	private static Object fetch(String address) {
		try {
			URL url = new URL(address);
			Object content = url.getContent();
			return content;
		} catch (Exception e) {
			Common.DoCatchOperation(e);
			return null;
		}
	}

	public static Date convertStringToDate(String dateFormatter, String strDate) {
		SimpleDateFormat dateFormat = new SimpleDateFormat(dateFormatter);
		Date date = null;
		try {
			date = dateFormat.parse(strDate);
		} catch (ParseException e) {
			Common.DoCatchOperation(e);
		}
		return date;
	}

	public static String convertDateToString(String dateFormatter, Date date) {
		if (date == null)
			return "";
		else {
			SimpleDateFormat dFormat = new SimpleDateFormat(dateFormatter);
			return dFormat.format(date);
		}
	}

	public static float convertTimeToFloat(String sTime) {
		float fTime = Float.parseFloat(sTime.split("\\:")[0]);
		switch (Integer.parseInt(sTime.split("\\:")[1])) {
		case 15:
			return fTime + 0.25f;
		case 30:
			return fTime + 0.50f;
		case 45:
			return fTime + 0.75f;
		default:
			return fTime;
		}
	}

	// public static boolean isTablet(Context context) {
	// TelephonyManager manager = (TelephonyManager) context
	// .getSystemService(Context.TELEPHONY_SERVICE);
	// if (manager.getPhoneType() == TelephonyManager.PHONE_TYPE_NONE) {
	// // Tablet
	// // boolean xlarge =
	// // ((context.getResources().getConfiguration().screenLayout &
	// // Configuration.SCREENLAYOUT_SIZE_MASK) ==
	// // Configuration.SCREENLAYOUT_SIZE_XLARGE);
	// //
	// // // If XLarge, checks if the Generalized Density is at least MDPI
	// // // (160dpi)
	// // if (xlarge) {
	// // DisplayMetrics metrics = new DisplayMetrics();
	// // Activity activity = (Activity) context;
	// // activity.getWindowManager().getDefaultDisplay()
	// // .getMetrics(metrics);
	// //
	// // // MDPI=160, DEFAULT=160, DENSITY_HIGH=240, DENSITY_MEDIUM=160,
	// // // DENSITY_TV=213, DENSITY_XHIGH=320
	// // if (metrics.densityDpi == DisplayMetrics.DENSITY_DEFAULT
	// // || metrics.densityDpi == DisplayMetrics.DENSITY_HIGH
	// // || metrics.densityDpi == DisplayMetrics.DENSITY_MEDIUM
	// // || metrics.densityDpi == DisplayMetrics.DENSITY_XHIGH) {
	//
	// // Yes, this is a tablet!
	// return true;
	// // }
	// // }
	// //
	// // // No, this is not a tablet!
	// // return false;
	// } else {
	// // Mobile
	// return false;
	// }
	// }

	// public static boolean isTabletDevice(Context activityContext) {
	// // Verifies if the Generalized Size of the device is XLARGE to be
	// // considered a Tablet
	//
	// }
	//
	public static boolean isTablet(Activity context) {

		// return context.getResources().getBoolean(R.bool.isTablet);
		try {
			// Compute screen size
			DisplayMetrics dm = context.getResources().getDisplayMetrics();
			float screenWidth = dm.widthPixels / dm.densityDpi;
			float screenHeight = dm.heightPixels / dm.densityDpi;
			double size = Math.sqrt(Math.pow(screenWidth, 2)
					+ Math.pow(screenHeight, 2));

			return size >= 6;
		} catch (Throwable e) {
			// CommonFunctions.DoCatchOperation(e);
			return false;
		}
	}

	public static boolean createDirIfNotExists(String path) {
		boolean ret = true;

		File file = new File(Environment.getExternalStorageDirectory(), path);
		if (!file.exists()) {
			if (!file.mkdirs()) {
				ret = false;
			}
		}
		return ret;
	}

	public static void SaveMessageToFile(File myFile, String Message) {

		FileOutputStream fOut;
		ObjectOutputStream myOutWriter = null;
		try {
			myFile.delete();
			myFile.createNewFile();
			fOut = new FileOutputStream(myFile);
			myOutWriter = new ObjectOutputStream(fOut);
			myOutWriter.writeObject(Message);
			myOutWriter.close();
			fOut.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();

		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			fOut = null;
			myOutWriter = null;
		}

	}

	public static String ReadMessageFromFile(File myFile) {
		FileInputStream fIn;

		ObjectInputStream ois = null;
		String c = null;
		try {
			fIn = new FileInputStream(myFile);
			ois = new ObjectInputStream(fIn);
			c = (String) ois.readObject();
			ois.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			ois = null;
			fIn = null;
		}
		return c;
	}

	public static File GetCatcheFilePath(String filename, Context context) {
		return new File(GetCatcheDir("", context), filename + ".dis");
	}

	public static File GetCatcheFilePath(String Dir, String filename,
			Context context) {
		return new File(GetCatcheDir(Dir, context), filename + ".dis");
	}

	public static File GetCatcheDir(String dirname, Context context) {
		File cacheDir;
		if (android.os.Environment.getExternalStorageState().equals(
				android.os.Environment.MEDIA_MOUNTED))
			cacheDir = new File(
					android.os.Environment.getExternalStorageDirectory(),
					context.getResources().getString(R.string.app_name)
							+ "/_temp"
							+ (Common.HasValue(dirname) ? "/" + dirname : ""));
		else
			cacheDir = new File(context.getCacheDir(), context.getResources()
					.getString(R.string.app_name)
					+ "/_temp"
					+ (Common.HasValue(dirname) ? "/" + dirname : ""));
		if (!cacheDir.exists())
			cacheDir.mkdirs();
		return cacheDir;

	}

	public static String convertStreamToString(InputStream is) {

		BufferedReader reader = new BufferedReader(new InputStreamReader(is));
		StringBuilder sb = new StringBuilder();

		String line = null;
		try {
			while ((line = reader.readLine()) != null) {
				sb.append((line + "\n"));
			}
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				is.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return sb.toString();
	}

	public static boolean isServiceRunning(Context c, String serviceClassName) {
		final ActivityManager activityManager = (ActivityManager) c
				.getSystemService(Context.ACTIVITY_SERVICE);
		final List<RunningServiceInfo> services = activityManager
				.getRunningServices(Integer.MAX_VALUE);

		for (RunningServiceInfo runningServiceInfo : services) {
			if (runningServiceInfo.service.getClassName().equals(
					serviceClassName)) {
				return true;
			}
		}
		return false;
	}

	public static String GetResponce(String url, String[] ParmsID,
			String[] ParamValues, String FileTag, File file) {
		String Responce = "";
		// Set SOAP objects...
		// HttpPost request = new HttpPost(CommonFunctions.wsURL + "/"+
		// METHOD_NAME);
		HttpRequestBase request = null;

		List<NameValuePair> params = new ArrayList<NameValuePair>();
		if (Common.HasValue(FileTag) && file != null && file.exists()) {
			Bitmap b = Common.decodeFile(file, 600, 600);
			if (b != null) {
				ByteArrayOutputStream bos = new ByteArrayOutputStream();

				b.compress(CompressFormat.JPEG, 90, bos);
				byte[] data = bos.toByteArray();
				params.add(new BasicNameValuePair(FileTag, Base64
						.encodeToString(data, Base64.DEFAULT)));

			}
		}
		// Add the required parameters
		if (ParmsID != null) {
			request = new HttpPost(url);
			for (int i = 0; i < ParmsID.length; i++) {
				params.add(new BasicNameValuePair(ParmsID[i],
						ParamValues[i] == null ? "" : ParamValues[i]));
			}
			try {
				((HttpPost) request).setEntity(new UrlEncodedFormEntity(params,
						HTTP.UTF_8));
			} catch (UnsupportedEncodingException e1) {
				Common.DoCatchOperation(e1);
				return Responce;
			}
		} else {
			request = new HttpGet(url);
		}

		// Send the request and get feedback
		HttpResponse httpResponse = null;
		try {
			httpResponse = new DefaultHttpClient().execute(request);
		} catch (ClientProtocolException e1) {
			Common.DoCatchOperation(e1);
			return Responce;
		} catch (IOException e1) {
			Common.DoCatchOperation(e1);
			return Responce;
		}

		try {
			int sCode = httpResponse.getStatusLine().getStatusCode();
			if (sCode == 200) {

				Responce = EntityUtils.toString(httpResponse.getEntity());
			} else {
				throw new IOException("WS Call Failed-" + sCode + ": url-->"
						+ url);
			}
			return Responce;
		} catch (Exception e) {
			Common.DoCatchOperation(e);
			return Responce;
		} finally {
			request = null;
			params = null;
			httpResponse = null;
		}
	}

	public static void ShowAlert(final String Message, final String Title,
			final Activity c) {
		c.runOnUiThread(new Runnable() {

			public void run() {

				AlertDialog.Builder builder = new AlertDialog.Builder(c);
				builder.setTitle(Title);
				builder.setMessage(Message);
				builder.setNeutralButton("OK", null);
				builder.show();
			}
		});
	}

	public static boolean checkNetworkRechability(Context a) {
		Boolean bNetwork = false;
		ConnectivityManager connectivityManager = (ConnectivityManager) a
				.getSystemService(Context.CONNECTIVITY_SERVICE);

		for (NetworkInfo networkInfo : connectivityManager.getAllNetworkInfo()) {
			int netType = networkInfo.getType();
			int netSubType = networkInfo.getSubtype();

			if (netType == ConnectivityManager.TYPE_WIFI) {
				bNetwork = networkInfo.isConnected();
				if (bNetwork == true)
					break;
			} else if (netType == 6) {
				bNetwork = networkInfo.isConnected();
				if (bNetwork == true)
					break;
			} else if (netType == ConnectivityManager.TYPE_MOBILE
					&& netSubType != TelephonyManager.NETWORK_TYPE_UNKNOWN) {
				bNetwork = networkInfo.isConnected();
				if (bNetwork == true)
					break;
			} else {
				bNetwork = false;
			}
		}
		return bNetwork;
	}

	public static int daysBetween(Date startDate, Date endDate) {
		Calendar sDate = getDatePart(startDate);
		Calendar eDate = getDatePart(endDate);

		int daysBetween = 0;
		while (sDate.before(eDate)) {
			sDate.add(Calendar.DAY_OF_MONTH, 1);
			daysBetween++;
		}
		return daysBetween;
	}

	public static int monthsBetween(Date startDate, Date endDate) {
		Calendar sDate = getDatePart(startDate);
		Calendar eDate = getDatePart(endDate);

		int daysBetween = 0;
		while (sDate.before(eDate)) {
			sDate.add(Calendar.MONTH, 1);
			daysBetween++;
		}
		return daysBetween;
	}

	public static JSONObject getLocationInfo(String address) {

		HttpGet httpGet = new HttpGet(
				"http://maps.google.com/maps/api/geocode/json?address="
						+ address.replace(" ", "%20") + "&sensor=false");
		HttpClient client = new DefaultHttpClient();
		HttpResponse response;
		StringBuilder stringBuilder = new StringBuilder();

		try {
			response = client.execute(httpGet);
			HttpEntity entity = response.getEntity();
			InputStream stream = entity.getContent();
			int b;
			while ((b = stream.read()) != -1) {
				stringBuilder.append((char) b);
			}
		} catch (ClientProtocolException e) {
		} catch (IOException e) {
		}

		JSONObject jsonObject = new JSONObject();
		try {
			jsonObject = new JSONObject(stringBuilder.toString());
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return jsonObject;
	}

	public static Spanned getFormatedDate(String date) {
		Spanned resultdate;

		String day = Common.getMeNthParamInString(date, " ", 1);
		String month = Common.getMeNthParamInString(date, " ", 2);
		String year = Common.getMeNthParamInString(date, " ", 3);
		resultdate = Html.fromHtml(day + "<sup><small>th</small></sup>" + " "
				+ month + " " + year);
		if (Integer.parseInt(day) == 02 || Integer.parseInt(day) == 22) {
			resultdate = Html.fromHtml(day + "<sup><small>nd</small></sup>"
					+ " " + month + " " + year);
		} else if (Integer.parseInt(day) == 01 || Integer.parseInt(day) == 21
				|| Integer.parseInt(day) == 31) {
			resultdate = Html.fromHtml(day + "<sup><small>st</small></sup>"
					+ " " + month + " " + year);
		} else if (Integer.parseInt(day) == 03 || Integer.parseInt(day) == 23) {
			resultdate = Html.fromHtml(day + "<sup><small>rd</small></sup>"
					+ " " + month + " " + year);
		}
		return resultdate;
	}

	public static Spanned getFormatedDay(String date) {
		Spanned resultdate;

		String day = Common.getMeNthParamInString(date, " ", 3);
		String month = Common.getMeNthParamInString(date, " ", 2);
		String year = Common.getMeNthParamInString(date, " ", 1);
		resultdate = Html.fromHtml(day + "<sup><small>th</small></sup>" + " "
				+ month + " " + year);
		if (Integer.parseInt(day) == 02 || Integer.parseInt(day) == 22) {
			resultdate = Html.fromHtml(day + "<sup><small>nd</small></sup>"
					+ " " + month + " " + year);
		} else if (Integer.parseInt(day) == 01 || Integer.parseInt(day) == 21
				|| Integer.parseInt(day) == 31) {
			resultdate = Html.fromHtml(day + "<sup><small>st</small></sup>"
					+ " " + month + " " + year);
		} else if (Integer.parseInt(day) == 03 || Integer.parseInt(day) == 23) {
			resultdate = Html.fromHtml(day + "<sup><small>rd</small></sup>"
					+ " " + month + " " + year);
		}
		return resultdate;
	}

	public static Calendar getDatePart(Date date) {
		Calendar cal = Calendar.getInstance(); // get calendar instance
		cal.setTime(date);
		cal.set(Calendar.HOUR_OF_DAY, 0); // set hour to midnight
		cal.set(Calendar.MINUTE, 0); // set minute in hour
		cal.set(Calendar.SECOND, 0); // set second in minute
		cal.set(Calendar.MILLISECOND, 0); // set millisecond in second

		return cal; // return the date part
	}

	public static boolean containsOnlyNumbers(String str) {

		// It can't contain only numbers if it's null or empty...
		if (str == null || str.length() == 0)
			return false;

		for (int i = 0; i < str.length(); i++) {

			// If we find a non-digit character we return false.
			if (!Character.isDigit(str.charAt(i)))
				return false;
		}

		return true;
	}

	private static Dialog alertPopupWindow = null;

	public static void closeAlertPopupWindow() {
		if (null != alertPopupWindow) {
			alertPopupWindow.dismiss();
			alertPopupWindow = null;
		}
	}

	public static Dialog showCustomAlertPopupWindow(final Context baseContext,
			final int popupLayoutResourceId) {

		alertPopupWindow = new Dialog(baseContext);
		alertPopupWindow.requestWindowFeature(Window.FEATURE_NO_TITLE);
		alertPopupWindow.getWindow().setBackgroundDrawableResource(
				android.R.color.transparent);
		alertPopupWindow.setContentView(popupLayoutResourceId);
		// alertPopupWindow.setTitle("Custom Dialog");
		alertPopupWindow.setCancelable(false);
		alertPopupWindow.show();

		// // cancel button to close pop-up window
		// final Button btnDismiss = (Button) alertPopupWindow
		// .findViewById(R.id.cancelButton);
		// if (btnDismiss != null) {
		// btnDismiss.setOnClickListener(new Button.OnClickListener() {
		// @Override
		// public void onClick(View v) {
		// closeAlertPopupWindow();
		// }
		// });
		// }

		// popupWindow.setFocusable(true);
		// popupWindow.update();
		return alertPopupWindow;

	}

	public static String getAddressFromLatAndLon(Context context, String lat,
			String Long) {
		String result = "";
		try {

			double latitude = Double.parseDouble(lat);
			double longitude = Double.parseDouble(Long);
			geocoder = new Geocoder(context, Locale.getDefault());

			addresses = geocoder.getFromLocation(latitude, longitude, 1);

			// String address = addresses.get(0).getAddressLine(0);
			String city = addresses.get(0).getLocality();
			// String state = addresses.get(0).getAdminArea();
			String country = addresses.get(0).getCountryName();
			// String postalCode = addresses.get(0).getPostalCode();
			// String knownName = addresses.get(0).getFeatureName();
			if (city != null) {
				result = city + ", ";
			}
			if (country != null) {
				result = result + country;
			}
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;
	}

}
