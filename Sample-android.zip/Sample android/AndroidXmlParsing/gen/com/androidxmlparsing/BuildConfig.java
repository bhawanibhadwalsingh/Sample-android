/** Automatically generated file. DO NOT MODIFY */
package com.androidxmlparsing;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}