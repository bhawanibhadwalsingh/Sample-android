package com.androidxmlparsing.model;

public class SongsList {
	String KEY_SONG = ""; // parent node
	String KEY_ID = "";
	String KEY_TITLE = "";
	String KEY_ARTIST = "";
	String KEY_DURATION = "";
	String KEY_THUMB_URL = "";



	public String getKEY_SONG() {
		return KEY_SONG;
	}

	public void setKEY_SONG(String kEY_SONG) {
		KEY_SONG = kEY_SONG;
	}

	public String getKEY_ID() {
		return KEY_ID;
	}

	public void setKEY_ID(String kEY_ID) {
		KEY_ID = kEY_ID;
	}

	public String getKEY_TITLE() {
		return KEY_TITLE;
	}

	public void setKEY_TITLE(String kEY_TITLE) {
		KEY_TITLE = kEY_TITLE;
	}

	public String getKEY_ARTIST() {
		return KEY_ARTIST;
	}

	public void setKEY_ARTIST(String kEY_ARTIST) {
		KEY_ARTIST = kEY_ARTIST;
	}

	public String getKEY_DURATION() {
		return KEY_DURATION;
	}

	public void setKEY_DURATION(String kEY_DURATION) {
		KEY_DURATION = kEY_DURATION;
	}

	public String getKEY_THUMB_URL() {
		return KEY_THUMB_URL;
	}

	public void setKEY_THUMB_URL(String kEY_THUMB_URL) {
		KEY_THUMB_URL = kEY_THUMB_URL;
	}



}
