### Updating an Android Activty UI from a Service

This project shows how to update the UI in an Android Activity from a background Service. [You can view the tutorial here](http://www.websmithing.com/2011/02/01/how-to-update-the-ui-in-an-android-activity-using-data-from-a-background-service/).

This source code has no licensing restrictions or guarantees. You are free to use it as you wish.