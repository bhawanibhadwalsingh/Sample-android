package com.example.androidanimation;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipDescription;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.AnimationDrawable;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.widget.DrawerLayout;
import android.util.Log;
import android.view.DragEvent;
import android.view.GestureDetector;
import android.view.GestureDetector.SimpleOnGestureListener;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnDragListener;
import android.view.View.OnTouchListener;
import android.view.ViewTreeObserver;
import android.view.ViewTreeObserver.OnGlobalLayoutListener;
import android.view.animation.Animation;
import android.view.animation.Animation.AnimationListener;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.ViewFlipper;

import com.example.androidanimation.ScalingUtilities.ScalingLogic;
import com.softprodigy.librarymsspro.Validator;

public class IntroductionActivity extends Activity implements OnDragListener {

	Button buttonPrevious, buttonNext;
	ViewFlipper viewSwitcher;

	Animation slide_in_lefttoright, slide_out_lefttoright,
			slide_in_righttoleft, slide_out_righttoleft;
	ImageView imv1, imv2, imv3, imv4, imv5, anim;
	boolean swipevalue = false;
	// //////////////////
	// ============ Drawer
	DrawerLayout mDrawerLayout;
	ListView mDrawerList;

	// MenuListAdapter mMenuAdapter;

	String[] subtitle;
	int[] icon;

	FrameLayout frameLayout;
	LayoutInflater layoutInflater;

	// ============= Drawer
	// ======= header layout id
	TextView tv_headerview;
	ImageView img_slideMenu;
	TextView tv_homebtn;

	// =========== Profile Banner id
	ImageView img_profileView, img_profileDarrow;

	TextView tv_usertotalVotes, tv_usertotalFavorite, tv_usertotalUpload;

	// =================================

	TextView titleview;
	ImageView imageView1, imageView2;
	LinearLayout mlinearimageview, mlinearimageview2, linearToproot;
	// TextView tv_ads;

	int dx, dy;
	int prevX, prevY;
	int swipeMinDistance;
	int swipeThresholdVelocity;
	int swipeMaxOffPath;
	private int _xDelta;
	private int _yDelta;
	private int _x2Delta;
	private int _y2Delta;

	Intent intent;

	ImageView img_favoriteView;
	ImageView rightvirticalview, leftvirticalview;
	int mrighttouchposition, mlefttouchposition;
	int mpreviousLeftpixel, mpreviousToppixel;
	int imageMaxHeight, imageMaxWidth;
	int slideSelect_Id = 0;
	boolean istouchVerticalline = false;
	int de_leftmargin, de_topmargin, de_rightmargin, de_bottommargin;
	String TAG = "HomeScreen";
	int rootStartpixelheight, rootEndpixelheight;
	float currentImageWidth = 30.0f;

	Context context = this;
	Animation favoriteAnim;
	Animation slideOut, slideIn;
	LinearLayout mSlidetop, custombarclick;
	Boolean updownfilter = true;

	boolean isDragImage1 = false;
	boolean isDragImage2 = false;
 Handler mhandler =null;
	// ////////////////

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.introduction_activity);
		final GestureDetector gdt = new GestureDetector(new GestureListener());
		// buttonPrevious = (Button) findViewById(R.id.prev);
		buttonNext = (Button) findViewById(R.id.next);
		viewSwitcher = (ViewFlipper) findViewById(R.id.ViewFlipper);

//		viewSwitcher.getInAnimation().setAnimationListener(
//				new AnimationListener() {
//
//					@Override
//					public void onAnimationStart(Animation animation) {
//						// TODO Auto-generated method stub
//						Log.d("Animation is start now",
//								"Animation is start now");
//					}
//
//					@Override
//					public void onAnimationRepeat(Animation animation) {
//						// TODO Auto-generated method stub
//						Log.d("Animation is start repeat",
//								"Animation is start repeat");
//
//					}
//
//					@Override
//					public void onAnimationEnd(Animation animation) {
//						// TODO Auto-generated method stub
//						Log.d("Animation is start end",
//								"Animation is start end");
//					}
//				});

		viewSwitcher.setDisplayedChild(0);

		// Using one of the built in animations:
		// viewSwitcher.SetInAnimation(this,
		// Android.Resource.Animation.SlideInLeft);
		// viewSwitcher.SetOutAnimation(this,
		// Android.Resource.Animation.SlideOutRight);

		if (viewSwitcher.getDisplayedChild() == 0
				|| viewSwitcher.getDisplayedChild() == 1) {
			buttonNext.setVisibility(View.INVISIBLE);
		}
		// /////////////

		imageView1 = (ImageView) findViewById(R.id.image1);
		imageView2 = (ImageView) findViewById(R.id.image2);
		titleview = (TextView) findViewById(R.id.textview);
		// tv_ads = (TextView) findViewById(R.id.ads);
		// img_favoriteView = (ImageView) findViewById(R.id.favoriteView);
		// mImageLayout =(ViewGroup) findViewById(R.id.imgrootview);
		// mImage2Layout =(ViewGroup) findViewById(R.id.imgrootview2);
		// mlinearimageview = (LinearLayout) findViewById(R.id.imgrootview);
		// mlinearimageview2=(LinearLayout) findViewById(R.id.imgrootview2);

		rightvirticalview = (ImageView) findViewById(R.id.rightview);
		leftvirticalview = (ImageView) findViewById(R.id.leftview);
		linearToproot = (LinearLayout) findViewById(R.id.linearToproot);

		imageView2.setOnTouchListener(touchListener);
		imageView1.setOnTouchListener(touchListener);
		linearToproot.setOnDragListener(this);
		// ///////////

		imv1 = (ImageView) findViewById(R.id.imv1);
		imv2 = (ImageView) findViewById(R.id.imV2);
		imv3 = (ImageView) findViewById(R.id.imv3);
		imv4 = (ImageView) findViewById(R.id.imv4);
		// imv5 = (ImageView) findViewById(R.id.imv5);
		anim = (ImageView) findViewById(R.id.imvaim);
		anim.setBackgroundResource(R.anim.animation);
		// imv4 = (ImageView) findViewById(R.id.imv4);

		imv1.setImageResource(R.drawable.circle_two);
		imv2.setImageResource(R.drawable.circle_one);
		imv3.setImageResource(R.drawable.circle_one);
		imv4.setImageResource(R.drawable.circle_one);
		// imv5.setImageResource(R.drawable.circle_one);
		slide_in_lefttoright = AnimationUtils.loadAnimation(this,
				R.anim.in_from_right);
		slide_out_lefttoright = AnimationUtils.loadAnimation(this,
				R.anim.out_to_left);

		setTreeviewObserver();
		// imv1.setImageResource(R.drawable.circle_two);
		viewSwitcher.setOnTouchListener(new OnTouchListener() {
			@Override
			public boolean onTouch(final View view, final MotionEvent event) {
				gdt.onTouchEvent(event);
				return true;
			}
		});

		/*
		 * buttonPrevious.setOnClickListener(new OnClickListener() {
		 * 
		 * @Override public void onClick(View arg0) {
		 * 
		 * Toast.makeText(getApplicationContext(), "Showing previous view..",
		 * Toast.LENGTH_SHORT).show(); viewSwitcher.showPrevious(); } });
		 */

		buttonNext.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {

				int am = viewSwitcher.getDisplayedChild();
				System.out.println("bhawani>>>>" + am);
				buttonNext.setVisibility(View.INVISIBLE);
				if (am == 0) {

					imv1.setImageResource(R.drawable.circle_one);
					imv2.setImageResource(R.drawable.circle_two);
					imv3.setImageResource(R.drawable.circle_one);
					imv4.setImageResource(R.drawable.circle_one);
					// imv5.setImageResource(R.drawable.circle_one);
					buttonNext.setVisibility(View.INVISIBLE);
					viewSwitcher.setInAnimation(slide_in_lefttoright);
					viewSwitcher.setOutAnimation(slide_out_lefttoright);
					viewSwitcher.showNext();
					// imv4.setImageResource(R.drawable.circle_one);
				} else if (am == 1) {
					imv1.setImageResource(R.drawable.circle_one);
					imv2.setImageResource(R.drawable.circle_one);
					imv3.setImageResource(R.drawable.circle_two);
					imv4.setImageResource(R.drawable.circle_one);
					// imv5.setImageResource(R.drawable.circle_one);
					buttonNext.setVisibility(View.VISIBLE);
					viewSwitcher.setInAnimation(slide_in_lefttoright);
					viewSwitcher.setOutAnimation(slide_out_lefttoright);
					try {
						AnimationDrawable frameAnimation = (AnimationDrawable) anim
								.getBackground();
						frameAnimation.getCurrent();
						frameAnimation.start();

					} catch (Exception e) {
						// TODO: handle exception
					}
					viewSwitcher.showNext();
					// imv4.setImageResource(R.drawable.circle_one);
				} else if (am == 2) {
					imv1.setImageResource(R.drawable.circle_one);
					imv2.setImageResource(R.drawable.circle_one);
					imv3.setImageResource(R.drawable.circle_two);
					imv4.setImageResource(R.drawable.circle_one);
					// imv5.setImageResource(R.drawable.circle_one);
					viewSwitcher.setInAnimation(slide_in_lefttoright);
					viewSwitcher.setOutAnimation(slide_out_lefttoright);
					buttonNext.setVisibility(View.VISIBLE);
					viewSwitcher.showNext();
					// imv4.setImageResource(R.drawable.circle_one);
				} else if (am == 3) {
					imv1.setImageResource(R.drawable.circle_one);
					imv2.setImageResource(R.drawable.circle_one);
					imv3.setImageResource(R.drawable.circle_one);
					imv4.setImageResource(R.drawable.circle_two);
					// imv5.setImageResource(R.drawable.circle_two);
					viewSwitcher.setInAnimation(slide_in_lefttoright);
					viewSwitcher.setOutAnimation(slide_out_lefttoright);
					buttonNext.setVisibility(View.VISIBLE);
					viewSwitcher.showNext();
					// imv4.setImageResource(R.drawable.circle_one);
				}

			}
		});

		// int animr = viewSwitcher.getDisplayedChild();
		//
		// if(animr==2){
		// try{
		// AnimationDrawable frameAnimation =
		// (AnimationDrawable) anim.getBackground();
		// frameAnimation.getCurrent();
		// frameAnimation.start();
		//
		//
		// }catch (Exception e) {
		// // TODO: handle exception
		// }
		// }

		setDefaultImage();

	}

	private static final int SWIPE_MIN_DISTANCE = 100;

	private static final int SWIPE_THRESHOLD_VELOCITY = 10;
	private static final int SWIPE_MIN_DISTANCEtop = 100;

	private class GestureListener extends SimpleOnGestureListener {
		private final String TAG = null;

		@Override
		public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX,
				float velocityY) {

			if (e1.getX() - e2.getX() > SWIPE_MIN_DISTANCE

			&& Math.abs(velocityY) > SWIPE_THRESHOLD_VELOCITY) {
//				swipevalue=true;
				
				if(swipevalue==false){
					swipevalue=true;
				System.out.println("@@@@@@@@@@@@@@@@@@@@@@@  Right to left");

				int am = viewSwitcher.getDisplayedChild();
				System.out.println("bhawani>>>>" + am);
				buttonNext.setVisibility(View.INVISIBLE);
				if (am == 0) {
					imv1.setImageResource(R.drawable.circle_one);
					imv2.setImageResource(R.drawable.circle_two);
					imv3.setImageResource(R.drawable.circle_one);
					imv4.setImageResource(R.drawable.circle_one);
					// imv5.setImageResource(R.drawable.circle_one);
					buttonNext.setVisibility(View.INVISIBLE);
					viewSwitcher.setInAnimation(slide_in_lefttoright);
					viewSwitcher.setOutAnimation(slide_out_lefttoright);

					if (viewSwitcher.isFlipping()) {
						System.out.println("case111");
						// viewSwitcher.showNext();
					} else {
						System.out.println("case222");

					}
					viewSwitcher.showNext();
					// imv4.setImageResource(R.drawable.circle_one);
				} else if (am == 1) {
					imv1.setImageResource(R.drawable.circle_one);
					imv2.setImageResource(R.drawable.circle_one);
					imv3.setImageResource(R.drawable.circle_two);
					imv4.setImageResource(R.drawable.circle_one);
					// imv5.setImageResource(R.drawable.circle_one);
					buttonNext.setVisibility(View.VISIBLE);
					viewSwitcher.setInAnimation(slide_in_lefttoright);
					viewSwitcher.setOutAnimation(slide_out_lefttoright);
					try {
						AnimationDrawable frameAnimation = (AnimationDrawable) anim
								.getBackground();
						frameAnimation.getCurrent();
						frameAnimation.start();

					} catch (Exception e) {
						// TODO: handle exception
					}
					if (viewSwitcher.isFlipping()) {
						System.out.println("case111");

					} else {
						System.out.println("case222");

					}
					viewSwitcher.showNext();
					// imv4.setImageResource(R.drawable.circle_one);
				} else if (am == 2) {
					imv1.setImageResource(R.drawable.circle_one);
					imv2.setImageResource(R.drawable.circle_one);
					imv3.setImageResource(R.drawable.circle_two);
					imv4.setImageResource(R.drawable.circle_one);
					// imv5.setImageResource(R.drawable.circle_one);
					viewSwitcher.setInAnimation(slide_in_lefttoright);
					viewSwitcher.setOutAnimation(slide_out_lefttoright);
					buttonNext.setVisibility(View.VISIBLE);
					if (viewSwitcher.isFlipping()) {
						System.out.println("case111");

					} else {
						System.out.println("case222");

					}

					viewSwitcher.showNext();
					// imv4.setImageResource(R.drawable.circle_one);
				} else if (am == 3) {
					imv1.setImageResource(R.drawable.circle_one);
					imv2.setImageResource(R.drawable.circle_one);
					imv3.setImageResource(R.drawable.circle_one);
					imv4.setImageResource(R.drawable.circle_two);
					// imv5.setImageResource(R.drawable.circle_two);
					viewSwitcher.setInAnimation(slide_in_lefttoright);
					viewSwitcher.setOutAnimation(slide_out_lefttoright);
					buttonNext.setVisibility(View.VISIBLE);
					if (viewSwitcher.isFlipping()) {
						System.out.println("case111");

					} else {
						System.out.println("case222");

					}

					viewSwitcher.showNext();
					// imv4.setImageResource(R.drawable.circle_one);
				}

				// else if (am == 2) {
				//
				//
				//
				//
				// // imv1.setImageResource(R.drawable.circle_two);
				// // imv2.setImageResource(R.drawable.circle_one);
				// // imv3.setImageResource(R.drawable.circle_one);
				//
				// // viewSwitcher.setDisplayedChild(0);
				//
				// }
				if(mhandler ==null)
				{
				 mhandler = new Handler();
					mhandler.postDelayed(new Runnable() {
						
						@Override
						public void run() {
							// TODO Auto-generated method stub
							try {
								swipevalue=false;
							} catch (Exception e) {
								// TODO: handle exception
							}finally{
								mhandler=null;
							}
							
						}
					},  650);
				}
				
				}
			} else if (e2.getX() - e1.getX() > SWIPE_MIN_DISTANCE

			&& Math.abs(velocityY) > SWIPE_THRESHOLD_VELOCITY) {
				System.out.println("@@@@@@@@@@@@@@@@@@@@@@@left to right");

			} else if (e1.getY() - e2.getY() > SWIPE_MIN_DISTANCEtop
					&& Math.abs(velocityY) > SWIPE_THRESHOLD_VELOCITY) {

				System.out.println("@@@@@@@@@@@@@@@@@@@@@@@Bottom to up");

			}

			return false;
		}
	}

	@Override
	public boolean onDrag(View view, DragEvent dragEvent) {
		// TODO Auto-generated method stub
		View draggedImageView = (View) dragEvent.getLocalState();

		// Handles each of the expected events
		final int X = (int) dragEvent.getX();
		final int Y = (int) dragEvent.getY();
		switch (dragEvent.getAction()) {

		case DragEvent.ACTION_DRAG_STARTED:

			Log.i(TAG, "drag action started");
			istouchVerticalline = false;
			RelativeLayout.LayoutParams lParams = (RelativeLayout.LayoutParams) view
					.getLayoutParams();
			_xDelta = X - lParams.leftMargin;
			_yDelta = Y - lParams.topMargin;
			_x2Delta = X - lParams.rightMargin;
			_y2Delta = Y - lParams.bottomMargin;
			mpreviousLeftpixel = lParams.leftMargin;
			mpreviousToppixel = lParams.topMargin;
			// tempY =Y;
			// Utils.e("", lParams.topMargin +
			// "on Y axis check "+_yDelta+" \t poinit Y"+Y);
			// ontouchSlideView(slideSelect_Id); For Activation Slider
			lParams = null;
			// Determines if this View can accept the dragged data
			if (dragEvent.getClipDescription().hasMimeType(
					ClipDescription.MIMETYPE_TEXT_PLAIN)) {
				Log.i(TAG, "Can accept this data");

				// returns true to indicate that the View can accept the dragged
				// data.
				return true;

			} else {
				Log.i(TAG, "Can not accept this data");

			}

			// Returns false. During the current drag and drop operation, this
			// View will
			// not receive events again until ACTION_DRAG_ENDED is sent.
			return false;

		case DragEvent.ACTION_DRAG_ENTERED:
			Log.i(TAG, "drag action entered");
			// the drag point has entered the bounding box
			return true;

		case DragEvent.ACTION_DRAG_LOCATION:
			Log.i(TAG, mlefttouchposition + "drag action location X-->"
					+ dragEvent.getX());

			Log.i(TAG, mrighttouchposition + "drag action location Y -->"
					+ dragEvent.getY());
			// if(dragEvent.getY()<rootStartpixelheight ||
			// dragEvent.getY()>rootEndpixelheight)
			// {
			// Log.i(TAG, rootStartpixelheight
			// +"drag action location Y 2-->"+rootEndpixelheight );
			// break;
			// }
			// LinearLayout.LayoutParams layoutParams =
			// (LinearLayout.LayoutParams) view
			// .getLayoutParams();
			/*
			 * triggered after ACTION_DRAG_ENTERED stops after
			 * ACTION_DRAG_EXITED
			 */

			// Utils.e("", view.getLeft()+
			// "  comparing  position  "+currentImageWidth);
			if (dragEvent.getX() - currentImageWidth <= mlefttouchposition
					&& !istouchVerticalline) {
				istouchVerticalline = true;
				// Utils.e("", "Success to Touch on left ");
				Validator.displyToast(context, "Congrats! You got it.");
			}
			// else {
			if (dragEvent.getX() + currentImageWidth >= mrighttouchposition
					&& !istouchVerticalline) {
				// Utils.e("", "Success to Touch on right ");
				istouchVerticalline = true;
				Validator.displyToast(context, "Congrats! You got it.");

				// }
			}

			return false;

		case DragEvent.ACTION_DRAG_EXITED:
			Log.i(TAG, dragEvent.getX() + "drag action exited" + imageMaxWidth);
			// the drag shadow has left the bounding box
			// if(dragEvent.getY()<rootStartpixelheight ||
			// dragEvent.getY()>rootEndpixelheight)
			// return false;
			// if(dragEvent.getX()<=imageMaxWidth/2 && !istouchVerticalline)
			// {
			// istouchVerticalline=true;
			// Utils.e("", "Success to Touch on left ");
			// Validator.displyToast(getActivity(), "Touch to left bar");
			// }
			//
			// // }
			// // else {
			// if(dragEvent.getX()>=imageMaxWidth/2 && !istouchVerticalline)
			// {
			// Utils.e("",
			// "Success to Touch on right ");istouchVerticalline=true;
			// Validator.displyToast(getActivity(), "Touch to right bar");
			//
			// }

			return true;

		case DragEvent.ACTION_DROP:
			/*
			 * the listener receives this action type when drag shadow released
			 * over the target view the action only sent here if
			 * ACTION_DRAG_STARTED returned true return true if successfully
			 * handled the drop else false
			 */
			switch (draggedImageView.getId()) {
			case R.id.image1:
				Log.i(TAG, "image1");

				return false;
			case R.id.image2:
				Log.i(TAG, "image2");
				return false;
				/*
				 * case R.id.tennis: Log.i(TAG, "Tennis ball"); ViewGroup
				 * draggedImageViewParentLayout = (ViewGroup) draggedImageView
				 * .getParent();
				 * draggedImageViewParentLayout.removeView(draggedImageView);
				 * LinearLayout bottomLinearLayout = (LinearLayout)
				 * receivingLayoutView;
				 * bottomLinearLayout.addView(draggedImageView);
				 * draggedImageView.setVisibility(View.VISIBLE); return true;
				 */
				/*
				 * case R.id.imageView1: Intent intent = new
				 * Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
				 * startActivityForResult(intent, 0); Log.i(TAG, "Rugby ball");
				 * return false;
				 */
			default:
				Log.i(TAG, "in default");
				return false;
			}

		case DragEvent.ACTION_DRAG_ENDED:

			Log.i(TAG, "-----------------drag action ended-----------");
			Log.i(TAG, "getResult: " + dragEvent.getResult());
			istouchVerticalline = false;
			currentImageWidth = 30;
			// LinearLayout.LayoutParams layoutP = (LinearLayout.LayoutParams)
			// view.getLayoutParams();
			//
			// layoutP.leftMargin = mpreviousLeftpixel;
			// layoutP.topMargin = mpreviousToppixel;
			// // layoutP.rightMargin = de_rightmargin; //-250;
			// // layoutP.bottomMargin = de_bottommargin;
			// layoutP.rightMargin = de_rightmargin; //-250;
			// layoutP.bottomMargin = de_bottommargin;//-250;

			// view.setLayoutParams(layoutP);

			// ontouchSlideView(slideSelect_Id); For Activation Slider
			// layoutP =null;
			// if the drop was not successful, set the ball to visible
			if (!dragEvent.getResult()) {
				Log.i(TAG, "setting visible");
				draggedImageView.setVisibility(View.VISIBLE);
				if (isDragImage1)
					isDragImage1 = false;
				if (isDragImage2)
					isDragImage2 = false;
			}
			// switch (draggedImageView.getId()) {
			// case R.id.image1:
			// mlinearimageview2.setOnDragListener(this);
			// break;
			// case R.id.image2:
			// mlinearimageview.setOnDragListener(this);
			// break;
			//
			// default:
			// break;
			// }
			//

			return true;
			// An unknown action type was received.
		default:
			Log.i(TAG, "Unknown action type received by OnDragListener.");
			break;
		}

		/*
		 * switch (draggedImageView.getId()) { case R.id.image1: Log.i(TAG,
		 * "image1"); mImage2Layout.invalidate(); return false; case
		 * R.id.image2: Log.i(TAG, "image2"); return false;
		 * 
		 * case R.id.tennis: Log.i(TAG, "Tennis ball"); ViewGroup
		 * draggedImageViewParentLayout = (ViewGroup) draggedImageView
		 * .getParent();
		 * draggedImageViewParentLayout.removeView(draggedImageView);
		 * LinearLayout bottomLinearLayout = (LinearLayout) receivingLayoutView;
		 * bottomLinearLayout.addView(draggedImageView);
		 * draggedImageView.setVisibility(View.VISIBLE); return true;
		 * 
		 * 
		 * 
		 * default: Log.i(TAG, "in default"); return false; }
		 */

		return false;
	}

	void onDragmethod(View imageView, ImageView img_view) {
		ClipData clipData = ClipData.newPlainText("", "");
		View.DragShadowBuilder shadowBuilder = new View.DragShadowBuilder(
				imageView);
		/*
		 * start the drag - contains the data to be dragged, metadata for this
		 * data and callback for drawing shadow
		 */
		if (img_view != null && currentImageWidth == 30) {
			Bitmap bitmap = ((BitmapDrawable) img_view.getDrawable())
					.getBitmap();
			if (bitmap != null) {
				int percent = 40;
				if (bitmap.getWidth() > bitmap.getHeight()) {
					percent = 50;
				}

				currentImageWidth = (float) (bitmap.getWidth() * percent);
				// Utils.e("",
				// currentImageWidth+" Height of bitmap "+bitmap.getWidth());
				currentImageWidth = currentImageWidth / 100;
				// Utils.e("",
				// currentImageWidth+" Height of bitmap 2 "+bitmap.getWidth());
				// bitmap.recycle();
				bitmap = null;
			}
			img_view = null;
		}

		imageView.startDrag(clipData, shadowBuilder, imageView, 0);
		// we're dragging the shadow so make the view invisible
		imageView.setVisibility(View.INVISIBLE);
	}

	OnTouchListener touchListener = new OnTouchListener() {

		@Override
		public boolean onTouch(View v, MotionEvent event) {
			// TODO Auto-generated method stub
			int id = v.getId();
			ImageView img_view = null;
			switch (id) {
			case R.id.image1:

				if (!isDragImage2) {
					img_view = imageView1;
					isDragImage1 = true;
				}
				// imageView2.setOnLongClickListener(null);
				// mImageLayout.setOnDragListener(this);
				// mImage2Layout.setOnDragListener(null);
				break;
			case R.id.image2:
				if (!isDragImage1) {
					img_view = imageView2;
					isDragImage2 = true;
				}

				// mImage2Layout.setOnDragListener(this);
				// mImageLayout.setOnDragListener(null);
				break;

			default:
				break;

			}
			if (img_view != null)
				onDragmethod(v, img_view);
			return true;
		}
	};

	void setDefaultImage() {
		Bitmap stickrbitmap = BitmapFactory.decodeResource(getResources(),
				R.drawable.coin_img_one);
		Bitmap stickrbitmap1 = BitmapFactory.decodeResource(getResources(),
				R.drawable.coin_img_two);
		// Bitmap unscaledBitmap =
		// ScalingUtilities.decodeResource(getResources(), R.drawable.picture,
		// imageMaxWidth, imageMaxHeight, ScalingLogic.FIT);
		//
		// // Part 2: Scale image
		// Bitmap scaledBitmap =
		// ScalingUtilities.createScaledBitmap(unscaledBitmap, imageMaxWidth,
		// imageMaxHeight, ScalingLogic.FIT);
		// unscaledBitmap.recycle();
		// unscaledBitmap = null;
		int dp = Utils.getScreenDensity();
		int height = Utils.getSizeInPixel(dp, this);
		int value = (height / 2) + (height / 4);
		// imageMaxWidth = imageView1.getWidth();
		// imageMaxHeight= imageView1.getHeight();

		stickrbitmap = ScalingUtilities.createScaledBitmap(stickrbitmap, value,
				value, ScalingLogic.FIT);
		stickrbitmap1 = ScalingUtilities.createScaledBitmap(stickrbitmap1,
				value, value, ScalingLogic.FIT);
		// Utils.getResizedBitmap(stickrbitmap, value,
		// value);Utils.getResizedBitmap(stickrbitmap, Utils.getSizeInPixel(dp,
		// context), Utils.getSizeInPixel((dp), context));
		Utils.e("", stickrbitmap.getHeight() + "---stickrbitmap 1"
				+ stickrbitmap.getWidth());
		Utils.e("", stickrbitmap1.getHeight() + "---stickrbitmap 2"
				+ stickrbitmap1.getWidth());
		if (stickrbitmap != null) {

			imageView1.setImageBitmap(stickrbitmap1);
			imageView2.setImageBitmap(stickrbitmap);
			stickrbitmap = null;
		}

	}

	// method

	void setTreeviewObserver() {
		ViewTreeObserver vto = linearToproot.getViewTreeObserver();

		vto.addOnGlobalLayoutListener(new OnGlobalLayoutListener() {
			@Override
			public void onGlobalLayout() {
				linearToproot.getViewTreeObserver()
						.removeGlobalOnLayoutListener(this);
				int w = linearToproot.getMeasuredWidth();
				int h = linearToproot.getMeasuredHeight();
				Utils.e("", "mlinearimageview " + linearToproot.getRight());
				Utils.e("", "mlinearimageview " + linearToproot.getLeft());
				rootStartpixelheight = linearToproot.getTop();
				rootEndpixelheight = linearToproot.getBottom();
				// w = mlinearimageview.getRight() -mlinearimageview.getLeft();
				// imageMaxHeight = h;
				Utils.e("", "rootStartpixelheight " + rootStartpixelheight);// 75
				Utils.e("", "rootEndpixelheight  " + rootEndpixelheight);// 321
				// Rect rectf = new Rect();

				imageMaxWidth = w;
				// imageView1.setLayoutParams(setGravityParam(imageView1, h,
				// w,mImageLayout));
				Utils.e("", w + "wid height " + h);

			}
		});

		/*
		 * ViewTreeObserver vto1 = mlinearimageview.getViewTreeObserver();
		 * 
		 * vto1.addOnGlobalLayoutListener(new OnGlobalLayoutListener() {
		 * 
		 * @Override public void onGlobalLayout() {
		 * mlinearimageview.getViewTreeObserver
		 * ().removeGlobalOnLayoutListener(this); int w =
		 * mlinearimageview.getMeasuredWidth(); int h=
		 * mlinearimageview.getMeasuredHeight(); Utils.e("",
		 * "mlinearimageview "+mlinearimageview.getRight()); Utils.e("",
		 * "mlinearimageview "+mlinearimageview.getLeft()); // w =
		 * mlinearimageview.getRight() -mlinearimageview.getLeft();
		 * imageMaxHeight = h; // imageMaxWidth = w; //
		 * imageView1.setLayoutParams(setGravityParam(imageView1, h,
		 * imageMaxWidth,mImageLayout)); Utils.e("", w+ "wid height "+h);
		 * 
		 * } });
		 * 
		 * ViewTreeObserver vto2 = mlinearimageview2.getViewTreeObserver();
		 * 
		 * vto2.addOnGlobalLayoutListener(new OnGlobalLayoutListener() {
		 * 
		 * @Override public void onGlobalLayout() {
		 * mlinearimageview2.getViewTreeObserver
		 * ().removeGlobalOnLayoutListener(this); //int w =
		 * mlinearimageview2.getMeasuredWidth(); int h=
		 * mlinearimageview2.getMeasuredHeight();
		 * 
		 * // imageView2.setLayoutParams(setGravityParam(imageView2, h,
		 * imageMaxWidth,mImage2Layout)); // Utils.e("", w+ "wid 2--height "+h);
		 * // onStartMethod(); } });
		 */
		ViewTreeObserver viewlinerightto = rightvirticalview
				.getViewTreeObserver();
		viewlinerightto.addOnGlobalLayoutListener(new OnGlobalLayoutListener() {

			@Override
			public void onGlobalLayout() {
				// TODO Auto-generated method stub
				rightvirticalview.getViewTreeObserver()
						.removeGlobalOnLayoutListener(this);
				mrighttouchposition = rightvirticalview.getLeft();
				Log.e("", "right " + mrighttouchposition);

			}
		});

		ViewTreeObserver viewlineleftto = leftvirticalview
				.getViewTreeObserver();
		viewlineleftto.addOnGlobalLayoutListener(new OnGlobalLayoutListener() {

			@Override
			public void onGlobalLayout() {
				// TODO Auto-generated method stub
				leftvirticalview.getViewTreeObserver()
						.removeGlobalOnLayoutListener(this);
				mlefttouchposition = leftvirticalview.getRight();
				Log.e("", "left " + mlefttouchposition);

			}
		});

	}

}
