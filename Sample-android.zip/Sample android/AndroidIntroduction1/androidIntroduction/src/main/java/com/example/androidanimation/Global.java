package com.example.androidanimation;




import android.app.Application;
import android.content.Context;

public class Global  extends Application{

	private static Context context;
	public static String Slide_titles[]=null;
	
	
	@Override
	public void onCreate() {
		// TODO Auto-generated method stub
		super.onCreate();
		Global.context = getApplicationContext();
		

		
		// Parse.com
		
		
		

		
	//	ParseHelper.getUserObjID();
	
		
	}
	
	
	
	
	
	
	public static Context getAppContext() {
        return Global.context;
    }
	
	

}
