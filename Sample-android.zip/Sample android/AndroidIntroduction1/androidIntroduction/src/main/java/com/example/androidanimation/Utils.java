package com.example.androidanimation;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.lang.reflect.Field;
import java.util.Random;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.telephony.TelephonyManager;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.ViewConfiguration;

import com.softprodigy.librarymsspro.SharedPreferencesHandler;

public class Utils {
	
	private static Pattern pattern;
	private static Matcher matcher;
	private static final String EMAIL_PATTERN = "^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@"
			+ "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";
	private static AlertDialog alert;
	
	

	public static final void e(String tag,String msg)
	{
		Log.e(tag, msg);
	}
	
	public static final void i(String tag,String msg)
	{
		Log.i(tag, msg);
	}
	
	public static boolean isApiLevelgearter14()
	{		
			if (Build.VERSION.SDK_INT >= 14)
				return true;
			else
				return false;	
		
	}
	
	public static Bitmap getResizedBitmap(Bitmap bm, int newHeight, int newWidth) {
		int width = bm.getWidth();
		int height = bm.getHeight();
		float scaleWidth = ((float) newWidth) / width;
		float scaleHeight = ((float) newHeight) / height;
		float middleX = newWidth / 2.0f;
		float middleY = newHeight / 2.0f;
		// Create a matrix for the manipulation
		Matrix matrix = new Matrix();

		// Resize the bit map
		matrix.postScale(scaleWidth, scaleHeight, middleX, middleY);

		// Recreate the new Bitmap
		Bitmap resizedBitmap =Bitmap.createBitmap(bm, 0, 0, width, height,	matrix, false);
		//Bitmap resizedBitmap =     Bitmap.createScaledBitmap(bm, (int)newWidth, (int)newHeight, true);       //

		// Canvas canvas = new Canvas(resizedBitmap);
		// canvas.setMatrix(matrix);
		// return canvas.drawBitmap(bm, middleX - bm.getWidth() / 2, middleY -
		// bm.getHeight() / 2, new Paint(Paint.FILTER_BITMAP_FLAG));
		return resizedBitmap;
	}
	
	
	public static int getSizeInPixel(int dp, Context context) {
		final float scale = context.getResources().getDisplayMetrics().density;
		return (int) (dp * scale + 0.5f);
	}

	
	public  static final int getScreenDensity()
	{
		
		 int density = Global.getAppContext().getResources().getDisplayMetrics().densityDpi;
		 int den=0;
		 switch (density) {
		 case DisplayMetrics.DENSITY_HIGH:
			 den = 300;
			break;
			case DisplayMetrics.DENSITY_MEDIUM:		
				 den = 280;
				break;
			case DisplayMetrics.DENSITY_LOW:
				 den = 250;
				break;
			case DisplayMetrics.DENSITY_XHIGH:
				 den = 320;
				break;
			case DisplayMetrics.DENSITY_XXHIGH:
				den =350;
				break;
			case DisplayMetrics.DENSITY_TV:
				den =420;
				break;
				
		default:
			 den = 150;
			break;
		}
		 return den;
	}
	
	//================== Image Capture function====================
	
//	public static void createAppfolder()
//	{
////		File storagePath = new File(ImageFolderPath);
//try {
//	if (!storagePath.exists())
//		storagePath.mkdirs();
//} catch (Exception e) {
//	// TODO: handle exception
//}
//finally{
//	storagePath =null;
//}
//		
//		
//	}
	
//	public static String saveImage(Bitmap ba, String filename) {
//		Log.e("", "save image method is called=" + ba);
//		Log.e("", "file name after download " + filename);
//		ByteArrayOutputStream bytes = null;
//		bytes = new ByteArrayOutputStream();
//		ba.compress(Bitmap.CompressFormat.JPEG, 100, bytes);
//		
//		Log.e("", "bitmap is created");
//		FileOutputStream fo = null;
//		
//		try {
//			if(filename !=null)
//			{
//				if(!filename.endsWith(IMAGE_EXTENSION))
//					filename = filename.concat(IMAGE_EXTENSION);
//			}
//			
//			File storagePath = new File(ImageFolderPath);
//
//			if (!storagePath.exists())
//				storagePath.mkdirs();			
//
//			File f = new File(storagePath, filename);
//			Utils.e("", "file exist to Before "+f.getAbsolutePath());
//			if(f.exists())
//				{
//				Utils.e("", "file exist to delete"+f.getAbsolutePath());
//				f.delete();
//				}
//			
//			f.createNewFile();
//			fo = new FileOutputStream(f);
//			fo.write(bytes.toByteArray());
//			fo.flush();
//			fo.close();
//
//			if (f.exists()) {
//				return f.getAbsolutePath();
//			} else
//				return "null";
//		} catch (IOException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//			return "null";
//		} finally {
//			if (fo != null) {
//				fo = null;
//			}
//			bytes =null;
//			
//		}
//
//	}

	public static final String generateRandom(int length) {
		Random random = new Random();
		char[] digits = new char[length];
		try {
			digits[0] = (char) (random.nextInt(9) + '1');
			for (int i = 1; i < length; i++) {
				digits[i] = (char) (random.nextInt(10) + '0');
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
		finally{
			random =null;
		}
		
		
		return new String(digits);
	}

	public static final void copyStream(InputStream input, OutputStream output)
			throws IOException {

		byte[] buffer = new byte[1024];
		int bytesRead;
		while ((bytesRead = input.read(buffer)) != -1) {
			output.write(buffer, 0, bytesRead);
		}
	}
	
	public static final Bitmap ImageRescale(String content) {

		Bitmap bitmap = null;
		BitmapFactory.Options option = new BitmapFactory.Options();
		option.inSampleSize = 1;
		bitmap = BitmapFactory.decodeFile(content, option);
		return bitmap;
	}

	  public static final Bitmap decodeFile(File f){
	        try {
	            //decode image size
	            BitmapFactory.Options o = new BitmapFactory.Options();
	            o.inJustDecodeBounds = true;
	            BitmapFactory.decodeStream(new FileInputStream(f),null,o);              
	            //Find the correct scale value. It should be the power of 2.
	            final int REQUIRED_SIZE=70;
	            int width_tmp=o.outWidth, height_tmp=o.outHeight;
	            int scale=1;
	            while(true){
	                if(width_tmp/2<REQUIRED_SIZE || height_tmp/2<REQUIRED_SIZE)
	                    break;
	                width_tmp/=2;
	                height_tmp/=2;
	                scale *=2;
	            }

	            //decode with inSampleSize
	            BitmapFactory.Options o2 = new BitmapFactory.Options();
	            o2.inSampleSize=scale;
	            return BitmapFactory.decodeStream(new FileInputStream(f), null, o2);
	        } catch (FileNotFoundException e) {}
	        return null;
	    }
	//================== Image Capture function====================
	  public static final int getphoneHeight()
	  {
		  DisplayMetrics displayMetrics = Global.getAppContext().getResources().getDisplayMetrics();
		 // int width = displayMetrics.widthPixels;
		  int height = displayMetrics.heightPixels;
		  displayMetrics =null;
		  return height;
	  }
	  public static final int getphoneWidth()
	  {
		  DisplayMetrics displayMetrics = Global.getAppContext().getResources().getDisplayMetrics();
		  int width = displayMetrics.widthPixels;
		//  int height = displayMetrics.heightPixels;
		  displayMetrics =null;
		  return width;
	  }
	  
	  public static final String getSupportString()
	  {
		  String finalString=null;
		  StringBuilder sb = new StringBuilder();
		  Configuration configuration =new Configuration();
		 
		  try {
//			sb.append("This information will help improve "+PreferenceConstantID.APP_NAME+" experience");
			sb.append("\n");
			sb.append("Device "+Build.DEVICE); //C5502
			sb.append("\n Display "+Build.DISPLAY); // 10.5.1.a.0.283
			sb.append("\n Build.MANUFACTURER "+Build.MANUFACTURER);// Sony
			sb.append("\n Build.MODEL "+Build.MODEL);//C5502
			sb.append("\n Build.PRODUCT "+Build.PRODUCT); //C5502
			sb.append("\n Build.VERSION.SDK_INT "+Build.VERSION.SDK_INT); // 19
		
			finalString =sb.toString();
			sb =null;
//			sb.append("Display "+Build.DISPLAY);
//			Utils.e("", " -- build details"+Build.DEVICE);
//			Utils.e("", " -- build details"+Build.DISPLAY);
//			Utils.e("", " -- build details"+Build.MANUFACTURER);
//			Utils.e("", " -- build details"+Build.MODEL);
//			Utils.e("", " -- build details"+Build.PRODUCT);
//			Utils.e("", " -- build details"+Build.VERSION.SDK_INT);
		return finalString;
			
		} catch (Exception e) {
			// TODO: handle exception
		}
		  return null;
	  }
	  
	  public static final void intenttoSendSupport(Context context ,String subject )
	  {
		  if(context !=null)
		  {
			  String str =	  Utils.getSupportString();
		      Intent  intent = new Intent(Intent.ACTION_SEND);
		        intent.setType("text/plain");
		        intent.putExtra(Intent.EXTRA_EMAIL, "emailaddress@emailaddress.com");
		        intent.putExtra(Intent.EXTRA_SUBJECT, "Subject");
		        intent.putExtra(Intent.EXTRA_TEXT, str);

		        context.startActivity(Intent.createChooser(intent, "Send Email"));
		        intent =null;
		  }
			
	  }
	
	  public static final void intenttoRatetheApp(Context context)
	  {
		  if(context !=null)
		  {
			  Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=" + "com.whatsapp"));
				context.startActivity(intent);
				intent =null;
		  }
			
	  }
	  
	  private static final void EmailValidator() {
			pattern = Pattern.compile(EMAIL_PATTERN);
		}

		public static final  boolean validateEmail(final String EmailID) {
			EmailValidator();
			matcher = pattern.matcher(EmailID);
			return matcher.matches();

		}
		
		public static final void gotoHomeScreen(Activity activity)
		{
			if(activity != null)
			{
				Intent startMain = new Intent(Intent.ACTION_MAIN);
		        startMain.addCategory(Intent.CATEGORY_HOME);
		        startMain.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
		        activity.startActivity(startMain);
		        startMain =null;
			}
		}
		
		public static final  void getOverflowMenu(Context context ) {

		     try {
		        ViewConfiguration config = ViewConfiguration.get(context);
		        Field menuKeyField = ViewConfiguration.class.getDeclaredField("sHasPermanentMenuKey");
		        if(menuKeyField != null) {
		            menuKeyField.setAccessible(true);
		            menuKeyField.setBoolean(config, false);
		        }
		    } catch (Exception e) {
		        e.printStackTrace();
		    }
		}
		
//		public static final void submenuIntent(Activity activity,int id)
//		{
//			if(activity !=null)
//			{
//				Intent intent =null;;
//				switch (id) {
//				case SubMenu_SUPPORT_FEEDBACK:
//					intent  = new Intent(activity, SupportScreen.class);
//					 intent.addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
//					
//					break;
//				case SubMenu_INFORMATION:
//					
//					break;		
//				case SubMenu_ABOUT:
//					
//					break;
//				default:
//					break;
//				}
//				if(intent !=null)
//				{
//					activity.startActivity(intent);
//					intent=null;
//				}
//			}
//			
//		}
		
	public static final void LogoutAlert(final Context context)
	{
		AlertDialog alertDialog =null;
		AlertDialog.Builder builder = null;
		//AlertDialog.Builder builder = new AlertDialog.Builder(context);
		if(Build.VERSION.SDK_INT < Build.VERSION_CODES.HONEYCOMB) {
		    builder = new AlertDialog.Builder(context);
		} else {
		    builder = new AlertDialog.Builder(context, AlertDialog.THEME_HOLO_DARK);
		}
		
		builder.setMessage("Do you want to logout?");
		builder.setCancelable(false);
		builder.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
			
			@Override
			public void onClick(DialogInterface arg0, int arg1) {
				// TODO Auto-generated method stub
				
				
			}
		});
		builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
			
			@Override
			public void onClick(DialogInterface dialog, int which) {
				// TODO Auto-generated method stub
				
			}
		});
		alertDialog =builder.create();
		alertDialog.show();
		
		
	}

	
	
//	public static final String getPhoneUniqueID()
//	{
//		String identifier = null;
//		TelephonyManager tm = (TelephonyManager) Global.getAppContext().getSystemService(Context.TELEPHONY_SERVICE);
//		try {
//			if(tm !=null)
//			{
//				identifier=		tm.getDeviceId();
//			}
//			//if (identifier == null || identifier .length() == 0)
//		//	      identifier = Secure.getString(Global.getAppContext().getContentResolver(),Secure.ANDROID_ID);
//		} catch (Exception e) {
//			// TODO: handle exception
//		}
////		finally{
////			tm =null;
////			if(identifier !=null)
////			{
////				Setting.PHONEUNIQUE_ID = identifier;
////				Utils.e("", "Phone Id "+identifier);
////				identifier =null;
////			}
////			else {
////				Setting.PHONEUNIQUE_ID="";
////			}
////		}		
//// return Setting.PHONEUNIQUE_ID;
//	}
	
	public static final void showOkDialog(String dlgText, Context parent) {
		
		if (parent == null && Global.getAppContext() != null) {
			parent = Global.getAppContext();
		}
		AlertDialog.Builder builder = new AlertDialog.Builder(parent);
		builder.setMessage(dlgText).setCancelable(false)

		.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
			public void onClick(DialogInterface dialog, int id) {
				alert.dismiss();
			}

		});

		alert = builder.create();
		alert.show();

	}
	
	
//	public static final void runonAsynTask() {
//		if (Setting.mAsynctask != null) {
//			if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB)
//				Setting.mAsynctask.executeOnExecutor(
//						AsyncTask.THREAD_POOL_EXECUTOR, new String[] { null });
//			else
//				Setting.mAsynctask.execute();
//		}
//
//	}
//	
	public static boolean isNetworkAvailable(Context context) {
		if (context == null && Global.getAppContext() != null) {
			context = Global.getAppContext();
		}
		NetworkInfo activeNetworkInfo = null;
		if (context != null) {
			ConnectivityManager connectivityManager = (ConnectivityManager) context
					.getSystemService(Context.CONNECTIVITY_SERVICE);
			activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
		/*	if (activeNetworkInfo == null) {
				Settings.NETWORK_STATUS = "";
				Settings.NETWORK_TYPE = "";
			} else {

				if (activeNetworkInfo.getType() == 1) {
					Settings.NETWORK_TYPE = "WiFi";
				}
				if (activeNetworkInfo.getType() == 0)
					Settings.NETWORK_TYPE = "3G";
				if (activeNetworkInfo.getType() == 0
						&& activeNetworkInfo.getType() == 1)
					Settings.NETWORK_TYPE = "WiFi";
				if (activeNetworkInfo.getType() == 6) {
					Settings.NETWORK_TYPE = "WiMax";
				}
			}*/
		}

		return activeNetworkInfo != null;
	}


//	public static  void setUsername(String name)
//	{
//		if(name !=null)
//		{
//			SharedPreferencesHandler.setStringValues(Global.getAppContext(), USERNAME_KEY, name);
//			Setting.APP_USERNAME =name;
//		}
//		
//	}
//	public static  void setPassword(String password)
//	{
//		if(password !=null)
//		{
//			SharedPreferencesHandler.setStringValues(Global.getAppContext(), PASSWORD_KEY, password);
//			Setting.APP_PASSWORD =password;
//		}
//		
//	}
//	public static  void setEmail(String email)
//	{
//		if(email !=null)
//		{
//			SharedPreferencesHandler.setStringValues(Global.getAppContext(), EMAIL_KEY, email);
//			Setting.APP_EMAIL =email;
//		}		
//	}
//	public static  void setUniqueKey(String key)
//	{
//		if(key !=null)
//		{
//			SharedPreferencesHandler.setStringValues(Global.getAppContext(), UNIQUE_ID_KEY, key);
//			Setting.USER_OBJ_ID =key;
//		}		
//	}
//	
	
//	public static  final boolean getLoginCredentials()
//	{		
//		Setting.APP_USERNAME = SharedPreferencesHandler.getStringValues(Global.getAppContext(), USERNAME_KEY);
//		Setting.APP_PASSWORD = SharedPreferencesHandler.getStringValues(Global.getAppContext(), PASSWORD_KEY);
//		Setting.APP_EMAIL = SharedPreferencesHandler.getStringValues(Global.getAppContext(), EMAIL_KEY);
//		Setting.USER_OBJ_ID = SharedPreferencesHandler.getStringValues(Global.getAppContext(), UNIQUE_ID_KEY);
//		if(Setting.APP_USERNAME !=null &&Setting.APP_USERNAME.length()>0 &&Setting.APP_PASSWORD !=null && Setting.APP_PASSWORD.length()>0)
//	{
//		return true;
//	}
//	else return false;
//		
//	
//	}
//	
//	 public static final void setUserloginStatus(boolean status)
//	 {
//		 SharedPreferencesHandler.setBooleanValues(Global.getAppContext(), IS_USER_LOGIN, status);
//	 }
	 
	
}
