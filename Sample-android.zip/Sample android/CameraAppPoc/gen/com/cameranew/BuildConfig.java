/** Automatically generated file. DO NOT MODIFY */
package com.cameranew;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}